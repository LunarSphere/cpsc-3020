#include "workqueue.h"
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>

typedef struct w_task{
    int id;
}w_task;

// should probably make a queue helper
struct wq{
    size_t queue_capacity;
    int front;
    int rear;
    w_task items[];
}Queue;

//make an empty queue
void initialzeQueue(struct wq *q){
    q->front = -1;
    q->rear = -1;
}
//is queue empty
bool is_wq_empty(struct wq *q){
    return (q->front == -1);
}
//is queue full
bool is_wq_full(struct wq *q){
    return (q->rear == q->queue_capacity-1);
}
//add an item to the queue
void enqueue(struct wq *q, w_task task){
    if (is_wq_full(q)){
        fprintf(stderr, "queue is full\n");
    }
    if (is_wq_empty(q)){
        q->front = 0;
    }
    q->rear++;
    q->items[q->rear] = task;
}
//remove an item from the queue
w_task dequeue(struct wq *q){
    w_task task;
    if (!is_wq_empty(q)){
        task = q->items[q->front];
    }
    if (q->front == q->rear){
        q->front = -1;
        q->rear = -1;
    }else{
        q->front++;
    }
    return task;
}

//deallocate queue mainly here so i remember to free the flexible array member
void exterminate_wq(struct wq *q){
    free(q);
}

//we might need this later currently a placeholder for a function to run when the thread is created 
void *tfn(void *arg){
    int *ptr_to_int = malloc(sizeof(int));
	*ptr_to_int = 47;
	return ptr_to_int;
}

// create a queue and worker threads (threadpool)
wq_t *wq_create(size_t num_workers, size_t queue_capacity){
    struct wq *q = malloc(sizeof(struct wq) + (queue_capacity * sizeof(w_task))); // Flexible array member from c99
    q->queue_capacity = queue_capacity;
    pthread_t threads[num_workers];
    for (int id = 0; id < num_workers-1; id++){
        pthread_create(&threads[id], NULL, tfn, NULL); //takes thread id, attributes, function, and arguments
    }
    return q;
}


// this part will take a minute to figure out good stopping point
wq_job_id_t wq_submit(wq_t *q, wq_job_fn fn, void *arg){
    // if queue full wait until task can be added.
    return 0;
}

void wq_wait(wq_t *q, wq_job_id_t *ids, int numids){
    // takes a list of task ids
    // waits until they all execute
    return;
}

void wq_shutdown(wq_t *q){
    // when called all worker threads complete their task and exit. 
    // abandon any tasks remaining on queue
    // free any allocated memory for queue and thread pool
    return;
}